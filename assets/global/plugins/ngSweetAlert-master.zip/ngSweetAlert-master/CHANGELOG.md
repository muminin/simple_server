## 1.1.1

## Features

  - expose showInputError and close methods from swal object


## 1.1.0

## Features

  - update angular ~1.3.0

Improvements:

 - Replace use of $timeout with $evalAsync


# 1.0.4


# 1.0.3

## Features

  - update sweetalert 0.2.0

## Bug Fixes

## Breaking Changes


# 1.0.2

## Features

## Bug Fixes

  - remove console.log

## Breaking Changes


# 1.0.1

## Features

## Bug Fixes

  - call SweetAlert.swal inside another SweetAlert.swal(

## Breaking Changes


# 1.0.0

## Features

  - SweetAlert.swal( "title" )
  - SweetAlert.swal( "title", "message" )
  - SweetAlert.swal( "title", "message", "type" )
  - SweetAlert.swal( {options} )
  - SweetAlert.success( "title", "message" )
  - SweetAlert.warning( "title", "message" )
  - SweetAlert.error( "title", "message" )
  - SweetAlert.info( "title", "message" )

## Bug Fixes

## Breaking Changes
